package io.example.eligibiltycheck;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EligibiltycheckApplication {

	public static void main(String[] args) {
		SpringApplication.run(EligibiltycheckApplication.class, args);
	}

}
